import React, { useState } from "react";
import { Lock, ArrowLeft, ShieldCheck, Key, Eye, EyeOff, AlertCircle } from "lucide-react";

interface AdminLoginProps {
  onVerify: (passcode: string) => Promise<{ success: boolean; error?: string }>;
  onBack: () => void;
}

export default function AdminLogin({ onVerify, onBack }: AdminLoginProps) {
  const [passcode, setPasscode] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!passcode.trim()) {
      setError("Vui lòng nhập mật mã quản trị.");
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      const result = await onVerify(passcode);
      if (!result.success) {
        setError(result.error || "Mật mã quản trị viên không chính xác.");
      }
    } catch (err) {
      setError("Có lỗi xảy ra khi kết nối đến máy chủ.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-md mx-auto my-12 bg-white rounded-3xl border border-emerald-100 p-8 shadow-xl glow-shadow font-sans animate-fade-in">
      {/* Icon and Title */}
      <div className="text-center space-y-3 mb-8">
        <div className="w-16 h-16 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-700 mx-auto shadow-sm">
          <ShieldCheck size={32} className="stroke-[2]" />
        </div>
        <div className="space-y-1">
          <h2 className="font-display font-extrabold text-xl text-emerald-950 tracking-tight">
            Xác Thực Ban Quản Trị
          </h2>
          <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
            Vui lòng cung cấp mật mã quản sĩ của Ban Tổ chức để quản lý tài liệu và các kỳ thi.
          </p>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-rose-50 border border-rose-100 text-rose-800 rounded-2xl text-xs flex items-start gap-2.5 font-sans leading-relaxed">
          <AlertCircle size={16} className="text-rose-600 shrink-0 mt-0.5" />
          <div>
            <span className="font-bold block mb-0.5">Xác thực thất bại</span>
            <span className="font-medium text-rose-700">{error}</span>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-xs font-bold uppercase text-slate-400 tracking-wider mb-2 flex items-center gap-1.5">
            <Lock size={13} className="text-emerald-600" />
            <span>Mật mã quản trị viên *</span>
          </label>
          <div className="relative">
            <input
              id="admin-passcode-input"
              type={showPassword ? "text" : "password"}
              value={passcode}
              onChange={(e) => setPasscode(e.target.value)}
              placeholder="Mặc định: admin123"
              className="w-full bg-slate-50 border border-slate-250 focus:border-emerald-500 focus:bg-white focus:ring-1 focus:ring-emerald-500 outline-none rounded-xl pl-4 pr-11 py-3 text-slate-700 text-sm transition-all font-mono tracking-wide"
              required
              disabled={isLoading}
              autoFocus
            />
            <button
              id="btn-toggle-passcode-visibility"
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
            >
              {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
            </button>
          </div>
        </div>

        <div className="space-y-3">
          <button
            id="btn-submit-admin-login"
            type="submit"
            disabled={isLoading}
            className={`w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 active:bg-emerald-850 text-white font-bold py-3.5 px-6 rounded-xl text-xs flex items-center justify-center gap-2 transition-all glow-button ${
              isLoading ? "opacity-75 cursor-not-allowed" : "cursor-pointer"
            }`}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin h-4 w-4 text-white" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>Đang xác thực bảo mật...</span>
              </>
            ) : (
              <>
                <Key size={14} />
                <span>Đăng Nhập Quản Trị</span>
              </>
            )}
          </button>

          <button
            id="btn-back-to-submission"
            type="button"
            onClick={onBack}
            disabled={isLoading}
            className="w-full bg-white hover:bg-slate-50 text-slate-500 border border-slate-200/80 font-semibold py-3 px-6 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <ArrowLeft size={13} />
            <span>Quay lại cổng nộp bài</span>
          </button>
        </div>
      </form>
    </div>
  );
}
